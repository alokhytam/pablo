const fs = require('fs');
const path = require('path');
const { EmbedBuilder } = require('discord.js');
const { LOG_CHANNEL_ID, channelTitle } = require('./constants');

// Path menuju logCounter.json
const logFile = path.join(__dirname, 'data', 'logCounter.json');

// Fungsi untuk ambil & update nomor log
function getLogCount() {
  try {
    const data = JSON.parse(fs.readFileSync(logFile, 'utf8'));
    data.count += 1;
    fs.writeFileSync(logFile, JSON.stringify(data, null, 2));
    return data.count.toString().padStart(4, '0'); // Format: 0001
  } catch (err) {
    console.error('Gagal membaca logCounter.json:', err);
    return '0000';
  }
}

// Fungsi kirim embed log
async function sendLog(client, {
  user,
  action,
  status = '✅ Berhasil',
  reason = '',
  rawContent = '',
  channelId = '',
}) {
  try {
    const channel = await client.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
    if (!channel) return;

    const nomorLog = getLogCount();
    const channelName = channelTitle[channelId] || 'Unknown Channel';

    const embed = new EmbedBuilder()
      .setColor(status.includes('Gagal') ? 0xff0000 : 0x00cc66)
      .setAuthor({ name: `👤 LOGS SERVER #${nomorLog}` })
      .setDescription(`**Aksi:** ${action}\n**User:** ${user.tag} (ID: ${user.id})\n**Status:** ${status}${reason ? `\n**Alasan:** ${reason}` : ''}`)
      .addFields([
        {
          name: 'Konten',
          value: `📌 ${channelName}\n${rawContent?.slice(0, 1000) || 'Tidak ada konten.'}`,
        },
      ])
      .setFooter({ text: 'XIOO Logger' })
      .setTimestamp();

    await channel.send({ embeds: [embed] });

  } catch (err) {
    console.error('Gagal mengirim log:', err);
  }
}

module.exports = { sendLog };
