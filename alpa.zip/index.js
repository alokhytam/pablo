require('dotenv').config();

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
});

const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

// Load semua handler dan fitur
try {
  require('./handlers/interactionHandler')(client);
  console.log('✅  interactionHandler loaded');
} catch (e) {
  console.error('❌  interactionHandler gagal:\n', e.stack);
}

client.commands = new Collection();
client.slashCommands = new Collection();

// ✅ Harus dipanggil duluan!
try {
  require('./handlers/commandLoader')(client);
  console.log('✅ commandLoader loaded');
} catch (e) {
  console.error('❌ commandLoader gagal:', e);
}

//LOG BAN & TIMEOUT
require('./handlers/eventLoader')(client);

// ✅ Dipanggil setelah commandLoader
try {
  require('./handlers/commandHandler')(client);
  console.log('✅ commands loaded');
} catch (e) {
  console.error('❌ commands gagal:', e);
}

try {
  require('./utils/autoEmbed')(client);
  console.log('✅ autoEmbed loaded');
} catch (e) {
  console.error('❌ autoEmbed gagal:', e);
}

client.once('ready', () => {
  console.log(`✅ Bot aktif sebagai ${client.user.tag}`);
});

// Login bot
const token = process.env.TOKEN;

if (!token) {
  console.error('❌ TOKEN tidak ditemukan di file .env');
  process.exit(1);
}

client.login(token);
