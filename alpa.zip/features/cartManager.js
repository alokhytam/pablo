const {
  ChannelType,
  PermissionsBitField,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');

const userCartChannels = new Map(); // userId -> TextChannel
const userAddedMessages = new Map(); // userId -> Set of messageId

async function handleCart(interaction, client, sellerId) {
  const userId = interaction.user.id;
  const guild = interaction.guild;
  const username = interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 10);
  const embed = interaction.message.embeds?.[0];
  const messageId = interaction.message.id;

  if (!embed) return interaction.reply({ content: '❌ Tidak bisa menambahkan ke keranjang.', ephemeral: true });

  // Jika user sudah pernah menambahkan postingan ini
  if (!userAddedMessages.has(userId)) userAddedMessages.set(userId, new Set());
  const addedMessages = userAddedMessages.get(userId);
  if (addedMessages.has(messageId)) {
    return interaction.reply({ content: '⚠️ Postingan ini sudah ada di keranjangmu.', ephemeral: true });
  }

  // Cek kategori
  const category = guild.channels.cache.find(
    c => c.type === ChannelType.GuildCategory && c.name === '[ INFO RTM ]'
  );
  if (!category) return interaction.reply({ content: '❌ Kategori tidak ditemukan.', ephemeral: true });

  let cartChannel = userCartChannels.get(userId);

  // Cek apakah channel masih ada
  if (cartChannel && !guild.channels.cache.has(cartChannel.id)) {
    userCartChannels.delete(userId);
    cartChannel = null;
  }

  // Jika belum ada channel, buatkan
  if (!cartChannel) {
    const channelName = `🛒〢 keranjang-${username}`;
    cartChannel = await guild.channels.create({
      name: channelName,
      type: ChannelType.GuildText,
      parent: category.id,
      position: 0,
      permissionOverwrites: [
        {
          id: guild.id,
          deny: [PermissionsBitField.Flags.ViewChannel],
        },
        {
          id: userId,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ReadMessageHistory,
          ],
        },
        {
          id: client.user.id,
          allow: [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ManageChannels,
          ],
        },
      ],
    });
    userCartChannels.set(userId, cartChannel);
  }

  // Siapkan tombol
  const originalComponents = interaction.message.components[0]?.components || [];
  const filteredButtons = originalComponents.filter(btn =>
    !btn.customId?.startsWith('cart_') && !btn.customId?.startsWith('delete_')
  );

  const reminderButton = new ButtonBuilder()
    .setCustomId(`reminder_${userId}`)
    .setLabel('🔔 Ingatkan Saya')
    .setStyle(ButtonStyle.Secondary);

  const row1 = new ActionRowBuilder().addComponents(filteredButtons);
  const row2 = new ActionRowBuilder().addComponents(reminderButton);

  await cartChannel.send({
    content: `🛒 Produk ditambahkan ke keranjang oleh <@${userId}>`,
    embeds: [embed],
    components: [row1, row2]
  });

  addedMessages.add(messageId); // simpan id postingan agar tidak bisa ditambahkan ulang

  await interaction.reply({ content: '✅ Produk ditambahkan ke keranjangmu.', ephemeral: true });
}

module.exports = { handleCart };
