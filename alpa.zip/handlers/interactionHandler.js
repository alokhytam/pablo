const midman = require('../features/midman');
const dmSession = require('../features/dmSession');
const cartManager = require('../features/cartManager');
const reminderManager = require('../features/reminderManager'); // Tambahkan di atas (global)

module.exports = (client) => {
  console.log('📥  interactionHandler aktif');

  client.on('interactionCreate', async (interaction) => {
    console.log('🔘 Interaksi diterima:', interaction.customId);

    // Tombol ditekan
    if (interaction.isButton()) {
      const customId = interaction.customId;
      if (!customId) return;
      const [action, sellerId] = customId.split('_');

      if (customId === 'open_ticket') {
        return await midman.openTicket(interaction, client);
      }
      if (action === 'buy') {
        return await midman.handleBuy(interaction, client, sellerId);
      }
      if (action === 'chatpenjual') {
        return await dmSession.openSession(interaction, client);
      }
      if (action === 'cart') {
        return await cartManager.handleCart(interaction, client, sellerId);
      }
      if (action === 'reminder') {
        return await reminderManager.handleReminderButton(interaction, client);
      }
      if (action === 'minat') {
        return await dmSession.openSession(interaction, client, sellerId);
      }
      if (action === 'delete') {
        return await midman.deletePost(interaction, sellerId);
      }
      if (action === 'acceptorder') {
        return await midman.acceptOrder(interaction, client);
      }
      if (action === 'reply') {
        return await dmSession.handleReply(interaction);
      }
      if (action === 'ordermm') {
        const sessionId = sellerId;
        return await midman.handleOrderMMFromSession(interaction, client, sessionId);
      }
    }

    // Modal dikirim
    else if (interaction.isModalSubmit()) {
      const [modalAction, sessionId] = interaction.customId.split('_');

      if (modalAction === 'reminder') {
        return await reminderManager.handleReminderModal(interaction, client);
      }
      if (modalAction === 'modalreply') {
        return await dmSession.handleModalReply(interaction, client);
      }
    }
  });
};
