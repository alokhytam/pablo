//verifysubs
const verifySubscriber = require('../features/verifySubscriber');
// Deteksi spam link selain channel whitelist dan member whitelist
const allowedChannelId = '1393903007556698212';
const logChannelId = '1401373469979185162';
const exemptedMemberId = '1269015630921728080';
const linkRegex = /(https?:\/\/[^\s]+)/gi;

if (
  linkRegex.test(message.content) && // Deteksi link
  message.author.id !== exemptedMemberId && // Bukan member khusus
  message.channel.id !== allowedChannelId // Bukan channel whitelist
) {
  try {
    // Hapus pesan berisi link
    await message.delete();

    // Timeout 1 jam (3600 detik)
    await message.member.timeout(3600000, 'Spam link di channel tidak diizinkan');

    // Forward link ke log channel
    const logChannel = message.guild.channels.cache.get(logChannelId);
    if (logChannel) {
      await logChannel.send({
        content: `🚨 **Spam link terdeteksi dan dihapus!**
👤 Pengirim: <@${message.author.id}> \`(${message.author.tag})\`
📍 Channel asal: <#${message.channel.id}>
🔗 Konten:
${message.content}`
      });
    }
  } catch (err) {
    console.error('[SPAM LINK DETECTION ERROR]', err);
  }
}
  module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (!message.guild || message.author.bot) return;
    //verifysubs
    await verifySubscriber.execute(message, client);
    //prefix
    const prefix = '!';
    if (!message.content.startsWith(prefix)) return;
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    const command = client.commands.get(commandName);
    if (!command) return;
    try {
      await command.execute(client, message, args);
    } catch (error) {
      console.error(error); // hanya log di console
    }
  }
};
